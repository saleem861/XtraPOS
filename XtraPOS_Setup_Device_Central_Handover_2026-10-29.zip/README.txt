XtraPOS — Setup, Device, Central Management Handover
Release date: 2026-10-29

Files:
1. XtraPOS_Setup_Device_Central_Handover_2026-10-29.md
   Authoritative editable reference for Cursor, AI coding agents, and developers.
   Includes decisions, full flow trees, configuration data, synchronization,
   reset/deletion safeguards, testing, and current implementation status.

2. XtraPOS_Setup_Device_Central_Handover_2026-10-29.pdf
   21-page Arabic reading version for discussion and sharing.

IMPORTANT: This is the agreed functional/architectural handover. It is NOT
proof that every requirement was already implemented. See Section 17.
